목업배포주소
1. GITPAGE: https://deepdive-team1.github.io/youtube-mockup/
2. Netlify: https://youtubemockupteam1.netlify.app/

기획서 https://docs.google.com/document/d/1n1w_7GIqhbXqIAJQzJmerdd5vsGFKvEa-kFHn4E5Rv8/edit?usp=sharing

와이어프레임 https://www.figma.com/design/Pc1qaSoPkcP2YV7XHCEVTw/youtube-mockup-wireframe?node-id=0-1&p=f
